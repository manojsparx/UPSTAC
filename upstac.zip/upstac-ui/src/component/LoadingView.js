import React from 'react';

export function LoadingView(props) {
    return <div>Loading..</div>
}
